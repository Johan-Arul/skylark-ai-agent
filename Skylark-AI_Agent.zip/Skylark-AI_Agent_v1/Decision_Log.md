# Decision Log

## Monday.com Business Intelligence Agent

---

# 1. Overview

This document outlines key assumptions, design choices, trade-offs, and interpretations made during development.

The focus was reliability, clarity, and founder-level usefulness.

**Last Updated:** 25 February 2026

---

# 2. Key Assumptions

## 2.1 Board Structure

I had no direct access to the actual Monday.com board schema before building, so I made the following assumptions about column names and types:

**Deals Board assumed structure:**

| Column              | Assumed Type      | Fallback if Missing             |
| ------------------- | ----------------- | ------------------------------- |
| Deal Name           | Text              | Use row ID                      |
| Sector / Industry   | Dropdown/Text     | Flag as "Unknown"               |
| Deal Value          | Currency / Number | 0 (flagged in caveats)          |
| Status              | Status column     | Normalize to open/won/lost      |
| Expected Close Date | Date              | Exclude from time-based queries |
| Probability         | Number (%)        | Infer from status               |

**Work Orders Board assumed structure:**

| Column         | Assumed Type   | Fallback if Missing    |
| -------------- | -------------- | ---------------------- |
| Project Name   | Text           | Use row ID             |
| Linked Deal    | Connect Boards | Name-match fallback    |
| Billed Revenue | Currency       | 0 (flagged in caveats) |
| Status         | Status column  | Normalize              |
| Start Date     | Date           | Omit from time filters |

## 2.2 Data Linking

Assumed boards are linkable via at least one of:

- A **Connect Boards** column (linked item ID)
- A **shared deal name** or deal ID present in both boards

Fallback: fuzzy/normalized name matching (lowercase, strip whitespace).

**Why this matters:** Without linking, cross-board metrics like deal-to-WO conversion rate and pipeline-vs-realized revenue are impossible. The assumption held for the actual data, but 21.7% of deals had no close date and 52.3% had no deal value — both explicitly surfaced as caveats.

## 2.3 Query Intent

Assumed founders ask **outcome-driven, not technical** questions:

- "Are we overloaded?" → maps to active work order count vs. capacity
- "How are we doing?" → maps to pipeline + revenue + operations overview
- "What's closing this quarter?" → maps to date-filtered open deals

This drove the intent classification design — broad NL understanding, not keyword matching.

## 2.4 Data Quality

Assumed the Monday.com data is **inconsistently filled** — a realistic assumption for any live CRM. Built the system to:

- Never crash on missing data
- Always report what % of data is missing
- Still provide useful estimates with caveats when data is partial

## 2.5 User Base

Assumed the primary users are **founders and leadership** — not analysts. This shaped:

- Response style: insights-first, not raw tables
- Metric selection: pipeline, revenue, conversion rate, risk flags
- UI design: single chat box, one-click leadership update

---

# 3. Trade-offs Chosen and Why

## 3.1 Groq Llama 3.3 70B vs GPT-4o

|             | Groq Llama 3.3 70B                | GPT-4o              |
| ----------- | --------------------------------- | ------------------- |
| Cost        | Free                              | ~$10–15 / 1M tokens |
| Speed       | ~200 tok/s (fastest available)    | ~50-80 tok/s        |
| Quality     | Excellent for BI/analytical tasks | Best overall        |
| Reliability | Stable free tier                  | Requires paid key   |

**Chose Groq** because: the task is analytical (summarizing structured data), not creative. Llama 3.3 70B performs on par with GPT-4 on BI tasks. Zero cost removes friction for evaluation. GPT-4o would be the upgrade path for production.

## 3.2 Direct GraphQL API vs Monday.com MCP

**Chose Direct GraphQL API.**

Trade-off: more code to write (schema handling, pagination), but gives:

- Full control over which fields are fetched
- Simpler debugging (plain HTTP)
- No dependency on MCP server availability
- Faster iteration during development

## 3.3 In-Memory State vs Database

**Chose in-memory Pandas DataFrames** (refreshed every 5 minutes).

|                 | In-Memory             | Database (PostgreSQL) |
| --------------- | --------------------- | --------------------- |
| Setup time      | Minutes               | Hours                 |
| Query speed     | Fast (Pandas)         | Fast (SQL)            |
| Persistence     | ❌ Lost on restart    | ✅ Persistent         |
| Historical data | ❌ Current state only | ✅ Full history       |
| Complexity      | Low                   | High                  |

**Trade-off accepted:** No historical trend analysis (e.g. "how has our pipeline grown over 3 months?"). For the current use case (current state BI), this is acceptable.

## 3.4 Intent Classification vs Pure RAG

**Chose intent routing + structured analytics** over a pure RAG (retrieval-augmented generation) approach.

- **RAG approach:** embed all Monday.com data, semantic search, let LLM answer from chunks
- **Routing approach:** classify query, run targeted analytics, inject computed KPIs into LLM prompt

**Why routing wins here:** BI queries need precise arithmetic (total pipeline = sum of deal values). LLMs hallucinate numbers when doing math from raw text. Pre-computing KPIs with Pandas and feeding them to the LLM gives accurate numbers + natural language quality.

## 3.5 Single-Page Chat UI vs Full Dashboard

**Chose a single conversational interface** over a visual dashboard (charts, graphs).

**Why:** A dashboard shows fixed metrics. A chat interface lets founders ask questions they didn't know they had. More flexible, faster to build, and more useful for exploratory analysis.

**Trade-off:** No visual charts. A future version would add Chart.js panels alongside the chat.

## 3.6 No Authentication

**Chose no user authentication** for this version.

**Acceptable because:** This is an internal tool used by a small team. The Monday.com data is operational, not regulated (no PII, no financial secrets).

**Trade-off:** Anyone with the URL can access it. Production version should add OAuth or at minimum an API key gate.

---

# 4. LLM Selection

## Decision: Groq (Llama 3.3 70B) as Primary LLM

**Date:** 25 February 2026
**Replaces:** Google Gemini 1.5 Flash (original selection)

### Reason for Switch

|               | Gemini 1.5 Flash                | Groq (Llama 3.3 70B)   |
| ------------- | ------------------------------- | ---------------------- |
| Speed         | ~5-10s                          | ~1-2s (200+ tok/s)     |
| Free tier     | Limited                         | Generous free tier     |
| API stability | ❌ Model deprecated (404 error) | ✅ Stable              |
| Quality       | Very good                       | Excellent for BI tasks |

**Root Cause:** `gemini-1.5-flash` was deprecated in the v1beta API, returning a 404 error in production. Groq's Llama 3.3 70B was selected as a superior replacement — faster, free, and more stable.

**Trade-off:** Groq has rate limits on the free tier (~30 req/min). For heavy concurrent usage, a paid plan may be needed.

---

# 5. Intent Routing Design

## Original Design (5 rigid intents)

| Intent     | Trigger                                 |
| ---------- | --------------------------------------- |
| revenue    | Closed deals, billed amounts            |
| pipeline   | Open deals, future value                |
| operations | Work orders, backlog                    |
| crossboard | Conversion rates                        |
| leadership | Executive summary                       |
| ambiguous  | Everything else → ask for clarification |

**Problem Discovered:** The `crossboard` intent and any open-ended analytical question (e.g. "compare Mining vs Renewables") classified as `ambiguous`, causing the agent to refuse to answer rather than use its data context.

**Error observed:** `400 invalid_request_error` — conversation history was being sent to Groq in Gemini's format (`role: "model"`, `parts: [...]`) instead of Groq's format (`role: "assistant"`, `content: "..."`).

## Updated Design (6 intents + general catch-all)

Added `general` intent:

- **Handles:** Any dataset-related question not fitting a specific bucket
- **Prompt instruction:** "When in doubt, use GENERAL"
- **`ambiguous` now reserved for:** Truly off-topic queries only (greetings, coding questions, etc.)

**Impact:** Agent now freely answers any business question using the full analytics context (346 deals, 176 work orders).

---

# 6. Data Resilience Strategy

## Numeric Normalization

- "10k" → 10000, "₹10000" → 10000, Null → 0 (flagged in caveats)

## Date Normalization

- Parse multiple formats, convert to ISO, exclude invalid dates, report missing values

## Text Standardization

- Lowercase, trim whitespace, map similar statuses

## Data Caveats

The agent explicitly reports:

- % missing sector, % missing revenue, % missing dates

This improves leadership trust in the data.

---

# 7. Query Understanding

Mapped natural language to intent categories:

| Query           | Interpretation                      |
| --------------- | ----------------------------------- |
| Pipeline        | Open deal value                     |
| This quarter    | Date filter                         |
| Overloaded      | Active work orders                  |
| Conversion rate | Closed / Total                      |
| Compare sectors | general intent → LLM answers freely |

---

# 8. Deployment Architecture

## Decision: Railway (cloud deployment)

**Date:** 25 February 2026

|             | Railway          | Render              | Local only |
| ----------- | ---------------- | ------------------- | ---------- |
| Public URL  | ✅ Instant HTTPS | ✅ Yes              | ❌ No      |
| Cold starts | ✅ None          | ❌ Yes (15min idle) | N/A        |
| Free tier   | $5/mo credit     | Free                | Free       |
| Setup       | ⭐ Easiest       | Easy                | N/A        |

**Configuration:** `Procfile` + `railway.json` added to repo. `app.py` updated to read `$PORT` environment variable injected by Railway. Host set to `0.0.0.0` on cloud, `127.0.0.1` locally.

**Security:** All API keys stored as Railway environment variables, never committed to GitHub. `.gitignore` excludes `.env`.

---

# 9. How I Interpreted "Leadership Updates"

The brief asked for a "leadership update" feature. This required interpretation — leadership updates mean different things to different organisations.

## What I Ruled Out

- ❌ **Raw data dump** — tables of every deal. Leadership doesn't want to parse rows.
- ❌ **Single KPI highlight** — just one number is not enough context.
- ❌ **Generic summary** — "deals are going well" with no numbers is useless.

## What I Chose: Executive Decision-Support Brief

I interpreted a leadership update as a **structured, insight-driven summary** a founder would receive before a board meeting or Monday morning review. It must:

1. **State the current pipeline** — total open deal value, weighted by probability, this quarter vs. full pipeline
2. **Show sector breakdown** — where is the revenue concentrated? What's the diversification risk?
3. **Report closed revenue** — what has actually been won and billed YTD
4. **Surface operational status** — are we delivering what we sold? Active WOs, backlog, unbilled
5. **Flag conversion metrics** — deal win rate, deal-to-WO coverage (are won deals becoming projects?)
6. **Call out data quality issues** — explicitly state what % of data is missing so leadership knows how much to trust the numbers
7. **Provide actionable observations** — not just facts, but "this means X" and "recommended action: Y"

## Format Decision

Used **structured markdown with emoji section headers** — readable in a chat interface, easily copy-pasteable into Slack or email. Sections:

```
🔥 Pipeline Overview
💰 Revenue Performance
🔧 Operations Status
📊 Conversion & Efficiency
⚠️ Data Caveats
💡 Actionable Observations
```

## Two-Phase Generation

The leadership update is generated in two phases:

1. **Phase 1 — Compute:** Python analytics engine calculates all KPIs precisely (no LLM math)
2. **Phase 2 — Narrate:** LLM receives the structured data and adds insights, trends, and observations

This ensures numbers are accurate (Pandas arithmetic) while language is natural and insightful (Groq LLM).

---

# 10. What I'd Do Differently With More Time

## Immediate Improvements (next 24 hours)

1. **Add Redis caching** for computed analytics — avoid recomputing the same KPIs on every query. Current 5-minute in-memory refresh works but loses state on restart.

2. **Add user authentication** — even a simple API key check. Currently anyone with the URL can access company data.

3. **Streaming LLM responses** — stream Groq output token-by-token to the frontend so users see text appearing instantly rather than waiting 1-2 seconds for the full response.

## Short-Term (1 week)

4. **Visual charts** — embed Chart.js or Plotly graphs in the chat response when answering questions like "sector breakdown" or "pipeline trend". Numbers without visuals are harder to absorb.

5. **Historical data storage** — write daily snapshots to SQLite. Enables trend analysis: "how has our pipeline grown over the last 3 months?"

6. **Better board linking** — the current deal-to-WO linking uses name matching as a fallback. With more time I'd inspect the actual Monday.com Connect Boards column structure to get exact ID-based matching.

7. **Multi-board support** — currently handles exactly 2 boards. A more flexible architecture would auto-discover all boards and let the LLM query any of them.

## Medium-Term (1 month)

8. **Predictive revenue forecasting** — use historical win rates and deal stage durations to project next quarter revenue with confidence intervals.

9. **Anomaly detection** — flag deals that have been stuck in a stage too long, work orders with no linked deal, sectors with sudden pipeline drops.

10. **Automated weekly digest** — schedule a leadership update every Monday morning, email it as a formatted PDF.

11. **Natural language filters** — "show me only Tender sector deals over ₹50L closing this quarter" as a single query. Currently requires the user to ask follow-up questions.

12. **GPT-4o integration** — for complex multi-step reasoning (e.g. "what would our Q4 look like if our win rate improved by 10%?"). Groq Llama 3.3 70B is excellent for current BI tasks but GPT-4o handles nuanced hypotheticals better.

---

# 10. Risks & Mitigation

| Risk                         | Mitigation                                       |
| ---------------------------- | ------------------------------------------------ |
| Schema changes in Monday.com | Dynamic column detection                         |
| Weak board linking           | Fallback name matching                           |
| API rate limits              | Pagination & minimal field queries               |
| LLM API deprecation          | Groq primary + can add fallback                  |
| Free tier credit expiry      | App pauses (not deleted); restart from dashboard |

---

# 11. Future Improvements

With more time:

1. Add visualization dashboards (Chart.js or Plotly)
2. Add predictive revenue forecasting
3. Add anomaly detection (deals stalled, overdue WOs)
4. Automated weekly leadership email summary
5. Redis caching layer for faster responses
6. User authentication for multi-team access
7. GPT-4o integration for higher accuracy on complex queries

---

# 12. Why This Design Works

The system:

- Handles messy real-world data
- Provides contextual insights via Groq Llama 3.3 70B
- Dynamically integrates with live Monday.com data
- Surfaces data quality limitations transparently
- Supports leadership-level decision-making
- Deployable publicly via Railway in under 5 minutes

It avoids over-engineering and focuses on reliability and insight quality.
