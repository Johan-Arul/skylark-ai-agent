# 🚁 Skylark BI Agent

> Conversational AI Business Intelligence agent.
> Ask any question about your Monday.com pipeline, revenue, and work orders — in plain English.

---

## ✨ Features

- **Live Monday.com integration** — fetches real-time data via GraphQL API, refreshes every 5 minutes
- **Smart data cleaning** — handles missing values, ₹ format variants, date parsing, messy statuses
- **Cross-board analytics** — links Deals → Work Orders for conversion metrics
- **Groq Llama 3.3 70B** — ultra-fast (~1-2s), free, high-quality responses
- **Open-ended Q&A** — ask anything about the dataset, not just predefined questions
- **Leadership Update** — one-click structured executive summary with sector breakdown
- **Premium chat UI** — dark glassmorphism design, mobile-responsive

---

## 🚀 Quick Start (Local)

### 1. Install dependencies

```bash
python -m venv venv
venv\Scripts\activate        # Windows
pip install -r requirements.txt
```

### 2. Configure environment

```bash
copy .env.example .env
```

Edit `.env` and fill in:

| Key                   | Where to get it                                            |
| --------------------- | ---------------------------------------------------------- |
| `GROQ_API_KEY`        | [console.groq.com](https://console.groq.com) → free signup |
| `MONDAY_API_TOKEN`    | Monday.com → Profile → Admin → API                         |
| `DEALS_BOARD_ID`      | Open the Deals board → ID is in the URL                    |
| `WORKORDERS_BOARD_ID` | Open the Work Orders board → ID is in the URL              |

### 3. Run the server

```bash
python app.py
```

### 4. Open in browser

```
http://localhost:8000
```

---

## ☁️ Cloud Deployment (Railway)

Deploy publicly in ~5 minutes — no local setup needed for users.

1. Push code to GitHub (see `DEPLOY.md` for full steps)
2. Go to [railway.app](https://railway.app) → New Project → Deploy from GitHub
3. Add environment variables in Railway dashboard
4. Click **Generate Domain** → get a public HTTPS URL

Full guide: [`DEPLOY.md`](DEPLOY.md)

---

## 💬 Example Questions

**Revenue & Pipeline**

- _"What is our total open pipeline this quarter?"_
- _"Show me revenue breakdown by sector"_
- _"What revenue can we expect this month?"_
- _"Which deals are closing this quarter?"_

**Operations**

- _"Are we operationally overloaded?"_
- _"How many active work orders do we have?"_
- _"What is our unbilled backlog?"_

**Analytics**

- _"What is our deal-to-work-order conversion rate?"_
- _"Compare Mining vs Renewables pipeline"_
- _"Which sector has the most deals?"_
- _"What is our average deal size?"_

**Leadership**

- _"Give me a leadership update"_ (or click the button)

---

## 🔌 API Endpoints

| Method | Endpoint             | Description                    |
| ------ | -------------------- | ------------------------------ |
| `GET`  | `/health`            | Agent + data status            |
| `POST` | `/chat`              | Main chat endpoint             |
| `POST` | `/leadership-update` | Executive summary report       |
| `POST` | `/refresh`           | Force Monday.com data reload   |
| `GET`  | `/docs`              | Interactive API docs (Swagger) |

---

## 🏗️ Architecture

```
User → Chat UI (HTML/CSS/JS)
         ↓
      FastAPI (app.py)
         ↓
    SkylarkAgent (agent.py)
         ├── MondayClient  → GraphQL API → Monday.com boards
         ├── DataCleaner   → Pandas normalization
         ├── Analytics     → Aggregations, KPIs, sector breakdown
         └── Groq LLM      → Llama 3.3 70B for natural language responses
```

---

## 🛠️ Tech Stack

| Layer      | Technology                              |
| ---------- | --------------------------------------- |
| LLM        | Groq (Llama 3.3 70B) — free, 200+ tok/s |
| Backend    | FastAPI + Uvicorn                       |
| Data       | Pandas + Pydantic                       |
| Monday.com | GraphQL API (direct)                    |
| Frontend   | Vanilla HTML/CSS/JS                     |
| Deployment | Railway (cloud)                         |

---

## 🔒 Data Security

- API tokens stored in `.env` (never committed to git)
- `.gitignore` excludes `.env` — keys stay local or in Railway Variables
- Read-only Monday.com access — no data is written back
- No credentials ever logged

---

## 📁 Project Structure

```
Skylark-AI_Agent/
├── app.py              # FastAPI server + endpoints
├── agent.py            # Core AI agent + Groq LLM integration
├── analytics.py        # KPI calculations, sector breakdowns
├── data_cleaner.py     # Data normalization, date/currency parsing
├── monday_client.py    # Monday.com GraphQL client
├── prompts.py          # LLM prompts (system, intent classifier)
├── frontend/
│   ├── index.html      # Chat UI
│   ├── app.js          # Frontend logic
│   └── style.css       # Dark glassmorphism design
├── requirements.txt
├── Procfile            # Railway/Render start command
├── railway.json        # Railway deployment config
├── runtime.txt         # Python version pin
├── .env.example        # Environment variable template
├── DEPLOY.md           # Cloud deployment guide
└── Decision_Log.md     # Architecture & design decisions
```
